import ComponentIntro from "@/component/chap02/section01/Component";

function Section01() {
  return <ComponentIntro />;
}

export default Section01;
