export default function Section02() {
  return <FunctionComponent />;
}
