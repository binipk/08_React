import JSXRules from "@/component/chap01/section03/JSXRules";

export default function Section03() {
  return (
    <div>
      <JSXRules />
    </div>
  );
}
