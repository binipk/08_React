import JSXIntro from "@/component/chap01/section01/JSXIntro";

export default function Section01() {
  return (
    <div>
      {/* 컴포넌트 추가 */}
      <JSXIntro />
    </div>
  );
}
