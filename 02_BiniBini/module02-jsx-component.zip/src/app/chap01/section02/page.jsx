import JSXBasicSyntax from "@/component/chap01/section02/JSXBasicSyntax";

export default function Section02() {
  return (
    <div>
      <JSXBasicSyntax />
    </div>
  );
}
